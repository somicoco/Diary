package com.diary.project.service;

import java.util.List;
import java.util.Map;

import com.diary.project.vo.DiaryVo;
import com.diary.project.vo.FileInfoVo;
import com.diary.project.vo.UserVo;

public interface DiaryService {

	void insert(DiaryVo vo);

	List<DiaryVo> findAll(); 

//	public int before_schedule_add_search(DiaryVo vo);
////	public ArrayList<DiaryVo> schedule_list(DateData dateDate);
////	public DiaryVo get(int idx);
	List<DiaryVo> getdiaryList(String email);

	DiaryVo selectById(int d_no);

	List<UserVo> getdiaryListDiary(UserVo vo); 
	
	List<String> selectLastId();
	
	void fileInsert(List<FileInfoVo> savedFileNames);

	List<FileInfoVo> selectReplyByIdFiles(Integer valueOf);

	void deleteById(int d_no);

	DiaryVo selectIdByDiary(Integer d_no);

	void update(Map<String, Object> map);

	void fileUpdate(List<FileInfoVo> savedFileNames);

	void fileNullUpdate(int d_no);

	

	//List<FileInfoVo> selectReplyByIdFiles(Integer valueOf); 
	
}

package com.diary.project.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diary.project.dao.DiaryDao;
import com.diary.project.vo.DateData;
import com.diary.project.vo.DiaryVo;
import com.diary.project.vo.FileInfoVo;
import com.diary.project.vo.UserVo;


@Service
public class DiaryServiceImpl implements DiaryService{

	@Autowired
	private DiaryDao diaryDao;
	
	
	@Override
	public void insert(DiaryVo vo) {
		diaryDao.insert(vo);
		
	}

	@Override
	public List<DiaryVo> findAll() {
		return diaryDao.findAll();
	}
	@Override
	   public List<DiaryVo> getdiaryList(String email) {
	      // TODO Auto-generated method stub
	      return diaryDao.getdiaryList(email);
	   }


	   @Override
	   public DiaryVo selectById(int d_no) {
	      DiaryVo vo = diaryDao.selectById(d_no);      
	      vo.setD_content( vo.getD_content().replace("\r\n", "<br>") );
	      return vo;
	   }

	@Override
	public List<UserVo> getdiaryListDiary(UserVo vo) {
		return diaryDao.getdiaryListDiary(vo);
	}
	
	@Override
	public void fileInsert(List<FileInfoVo> savedFileNames) {
		// TODO Auto-generated method stub
		diaryDao.fileInsert(savedFileNames);
		
	}

	@Override
	public List<String> selectLastId() {
		// TODO Auto-generated method stub
		return diaryDao.selectLastId();
	}

	@Override
	public List<FileInfoVo> selectReplyByIdFiles(Integer d_no) {
		
		return diaryDao.selectReplyByIdFiles(d_no);
	}

	@Override
	public void deleteById(int d_no) {
		diaryDao.deleteById(d_no);
		
	}

	@Override
	public DiaryVo selectIdByDiary(Integer d_no) {
		// TODO Auto-generated method stub
		return diaryDao.selectIdByDiary(d_no);
	}


	@Override
	public void update(Map<String, Object> map) {
		// TODO Auto-generated method stub
		diaryDao.update(map);
	      
	}

	@Override
	public void fileUpdate(List<FileInfoVo> savedFileNames) {
		// TODO Auto-generated method stub
		diaryDao.fileUpdate(savedFileNames);
	}

	@Override
	public void fileNullUpdate(int d_no) {
		diaryDao.fileNullUpdate(d_no);
		
	}

	

}

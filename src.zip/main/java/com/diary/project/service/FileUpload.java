package com.diary.project.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import org.springframework.web.multipart.MultipartFile;
import com.diary.project.vo.FileInfoVo;

public class FileUpload {
	public static List<FileInfoVo> saveFileFromUI(ServletContext servletContext, 
			MultipartFile[] file, Integer id) throws IOException {
//		String realPath = servletContext.getRealPath("resources/upload");
		String realPath = "C:\\upload";
		System.out.println("realPath : "+realPath);
		String today = new SimpleDateFormat("yyMMdd").format(new Date());
		String saveFolder = realPath+File.separator;
		System.out.println("today : "+today);
		System.out.println("saveFolder : "+saveFolder);
		File folder = new File(saveFolder);
		if(!folder.exists()) // 저장 경로가 없으면 생성해 준다.
			folder.mkdir();
		
		List<FileInfoVo> savedFilenames = new ArrayList<FileInfoVo>();
		
		for (MultipartFile mfile : file) {
			String oriFName = mfile.getOriginalFilename();
			if(!oriFName.isBlank()) {
				String saveFileName = UUID.randomUUID().toString() 
						+ oriFName.substring(oriFName.lastIndexOf('.'));
				System.out.println("saveFileName : "+saveFileName);
				mfile.transferTo(new File(folder, saveFileName));
				
				FileInfoVo fileVo = new FileInfoVo();
				fileVo.setF_realFileName(oriFName);
				fileVo.setF_fileName(saveFileName);
				fileVo.setF_path(saveFolder);
				fileVo.setD_no(id);
				
				savedFilenames.add(fileVo);
			}
		}
		return savedFilenames;
	}
}
package com.diary.project.service;

import java.util.Map;

import com.diary.project.vo.UserVo;

public interface UserService {
	 

	void insert(UserVo vo);

	UserVo getMemberByEmail(String email);

	int idCheck(String id);

	int nickCheck(String id); 
	
	void updatePw(Map<String, Object> map);

	void updateProfile(Map<String, Object> map); 
	
}

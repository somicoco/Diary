package com.diary.project.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diary.project.dao.UserDao;
import com.diary.project.vo.UserVo;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;
	
	@Override
	public void insert(UserVo vo) {
		userDao.insert(vo);
		
	}

	@Override
	public UserVo getMemberByEmail(String email) {
		return userDao.getMemberByEmail(email);
		
	}

	@Override
	public int idCheck(String email) {
		int cnt = userDao.idCheck(email);
		return cnt;
	}

	@Override
	public int nickCheck(String id) {
		int cnt = userDao.nickCheck(id);
		return cnt;
	}
	@Override
	public void updatePw(Map<String, Object> map) {
		// TODO Auto-generated method stub
		userDao.updatePw(map);
		
	}

	@Override
	public void updateProfile(Map<String, Object> map) {
		userDao.updateProfile(map);
	}
	



	
}

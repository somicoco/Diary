package com.diary.project.dao;

import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.diary.project.vo.UserVo;

@Repository
public class UserDao {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public int insert(UserVo vo) {
		return sqlSessionTemplate.insert("user.insert",vo);
		}

	public UserVo getMemberByEmail(String email) {
		return sqlSessionTemplate.selectOne("user.getMemberByEmail",email);
	}

	public int idCheck(String email) {
		return sqlSessionTemplate.selectOne("user.idCheck",email);
	}

	public int nickCheck(String id) {
		return sqlSessionTemplate.selectOne("user.nickCheck",id);
	}
	
	public void updatePw(Map<String, Object> map) {
		sqlSessionTemplate.update("user.updatePw",map);
		
	}

	public void updateProfile(Map<String, Object> map) {
		sqlSessionTemplate.update("user.updateProfile",map);
		
	}
	
}

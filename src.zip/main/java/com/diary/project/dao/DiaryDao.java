package com.diary.project.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.diary.project.vo.DateData;
import com.diary.project.vo.DiaryVo;
import com.diary.project.vo.FileInfoVo;
import com.diary.project.vo.UserVo;

@Repository
public class DiaryDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public void insert(DiaryVo vo) {
		sqlSessionTemplate.insert("diary.insert",vo);
	}

//	public int before_schedule_add_search(DiaryVo vo) {
//		sqlSessionTemplate.select("diary.before_schedule_add_search", vo);
//		
//	}

	public List<Object> schedule_list(DateData dateDate) {
		return sqlSessionTemplate.selectList("diary.schedule_list", dateDate);
	}

	public List<Object> get(int idx) {
		return sqlSessionTemplate.selectList("diary.get", idx);
	}

	public List<DiaryVo> findAll() {
		 return sqlSessionTemplate.selectList("diary.findAll");
		
	}
	public List<DiaryVo> getdiaryList(String email) {
	      // TODO Auto-generated method stub
	      return sqlSessionTemplate.selectList("diary.getdiaryList",email);
	   }

	   public DiaryVo selectById(int d_no) {
	      // TODO Auto-generated method stub
	      return sqlSessionTemplate.selectOne("diary.selectById",d_no);
	   }

	public List<UserVo> getdiaryListDiary(UserVo vo) {
		  return sqlSessionTemplate.selectList("user.getdiaryListDiary",vo);
	}
	
	public void fileInsert(List<FileInfoVo> savedFileNames) {
		sqlSessionTemplate.insert("fileinfo.insert", savedFileNames);
		
	}

	public List<String> selectLastId() {
		return sqlSessionTemplate.selectList("diary.selectLastId");
	}
	
	

	public List<FileInfoVo> selectReplyByIdFiles(Integer d_no) {
		
		// TODO Auto-generated method stub
		return sqlSessionTemplate.selectList("fileinfo.selectReplyByIdFiles", d_no);
	}

	public void deleteById(int d_no) {
		sqlSessionTemplate.delete("diary.deleteById", d_no);
		
	}

	public DiaryVo selectIdByDiary(Integer d_no) {
		// TODO Auto-generated method stub
		return sqlSessionTemplate.selectOne("diary.selectIdByDiary", d_no);
	}

	public void update(Map<String, Object> map) {
		sqlSessionTemplate.update("diary.update",map);	
	}

	public void fileUpdate(List<FileInfoVo> savedFileNames) {
		sqlSessionTemplate.update("fileinfo.fileUpdate",savedFileNames);	
	}

	public void fileNullUpdate(int d_no) {
		sqlSessionTemplate.update("fileinfo.fileNullUpdate",d_no);	
		
	}
}

package com.diary.project.vo;

import java.util.Date;

import lombok.Data;

@Data
public class DiaryVo {
	
	int d_no; // 고유키
	String u_email; // 누가 일기쓴지 
	String create_dt; // 일기쓴 시간
	String d_title; // 일기제목
	String d_content; // 일기내용
	String d_category; //일기기분 
 	int f_id; //조인 할 파일 아이디
 	String d_today; // 오늘일기쓴 날짜 
	Date schedule_date;
	

	
}

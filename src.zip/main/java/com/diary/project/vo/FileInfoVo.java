package com.diary.project.vo;

import lombok.Data;

@Data
public class FileInfoVo {
   private int f_id;
   private int d_no;
   private String f_path;
   private String f_fileName;
   private String f_realFileName;   
   
   
}
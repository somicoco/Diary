package com.diary.project.vo;

import lombok.Data;

@Data
public class UserVo {
	
	private String u_email;
	private String u_pw;
	private String u_name;
	private String u_am;
	
}

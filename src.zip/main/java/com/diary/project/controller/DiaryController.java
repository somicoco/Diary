package com.diary.project.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.diary.project.service.DiaryService;
import com.diary.project.service.FileUpload;
import com.diary.project.service.UserService;
import com.diary.project.vo.DiaryVo;
import com.diary.project.vo.FileInfoVo;

@Controller
public class DiaryController {
	@Autowired
	ServletContext servletContext;
	
	@Autowired
	private DiaryService diaryService;

	@RequestMapping(value = "/diaryWrite", method = RequestMethod.GET)
	   public ModelAndView diarywrite() {
	      ModelAndView mv = new ModelAndView("mainPage/calendar_write");
	      return mv;
	   }

	   

	// 다이어리 일기 작성하는 컨트롤러
	@RequestMapping(value = "/diaryWrite", method = RequestMethod.POST)
	public ModelAndView uploadDiary(DiaryVo vo, HttpServletRequest req,
	         @RequestParam(value = "uploadfile", required = false) MultipartFile[] file
	        ) throws FileUploadException, IllegalStateException, IOException{

	    HttpSession session = req.getSession();
	    vo.setU_email(session.getAttribute("loginEmail").toString());
	    vo.setD_category(req.getParameter("radioTxt"));

	    Date nowDate = new Date();
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");  
	    simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    vo.setD_today(req.getParameter("start"));

	    System.out.println("vo.getD_today"+vo.getD_today());

	    diaryService.insert(vo);
	    
	    try {
	        if(file != null && file.length > 0) {
	            List<String> Lista = diaryService.selectLastId();
	            List<FileInfoVo> savedFileNames = FileUpload.saveFileFromUI(servletContext, file,Integer.valueOf(Lista.get(0))); 
	            diaryService.fileInsert(savedFileNames);
	        } else {
	            System.out.println("파일없음");
	        }
	    } catch (Exception e) {
	        // 예외 처리 로직
		    ModelAndView mv = new ModelAndView("redirect:/calendar");
		    return mv;
	    }

	    ModelAndView mv = new ModelAndView("redirect:/calendar");
	    return mv;
	}



	@RequestMapping(value = "/diaryUpdate", method = RequestMethod.GET)
	   public ModelAndView diarywrite(@RequestParam("id") Integer d_no ) {
	       System.out.println(d_no);
	       DiaryVo updateVo = null;
	       ModelAndView mv = new ModelAndView();
	           DiaryVo selectDiary = diaryService.selectIdByDiary(d_no);
	           List<FileInfoVo> files = diaryService.selectReplyByIdFiles(Integer.valueOf(d_no));
	           System.out.println(files);
	           System.out.println("가지고온 값은??"+selectDiary.getD_category());
	           mv = new ModelAndView("mainPage/calendar_update");
	           mv.addObject("selectDiary",selectDiary);
	       return mv;
	   }
	   
	   
	   @RequestMapping(value = "/diaryUpdate", method = RequestMethod.POST)
	   public ModelAndView updateDiary(Map<String, Object> map,HttpServletRequest req,
	         @RequestParam("id") int d_no,@RequestParam(required = false, value= "uploadfile") MultipartFile[] file
	         )throws FileUploadException, IllegalStateException, IOException{
	      
	      // 여기에 넘버 찍히고
	      // 조건문 만들어서 넘버가 있으면 없으면 
	      System.out.println("테스트업데이트");
	      System.out.println("@@@d_no"+d_no);
  
	        Date nowDate = new Date();
	        SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyyMMdd");  
	        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//	        System.out.println("@@@@@@@@vo의 값은?"+vo);
	        
	        map.put("d_no",d_no); 
	       map.put("d_title",req.getParameter("d_title")); 
	       map.put("d_content",req.getParameter("d_content")); 
	       map.put("d_category", req.getParameter("radioTxt"));
	       map.put("create_dt", "");
	        diaryService.update(map);

	      try {
	    	  List<FileInfoVo> savedFileNames = FileUpload.saveFileFromUI(servletContext, file,Integer.valueOf(d_no)); 
	    	  diaryService.fileUpdate(savedFileNames);
		} catch (Exception e) {
			System.out.println("파일이 없네?");
			diaryService.fileNullUpdate(d_no);
//			 ModelAndView mv = new ModelAndView("redirect:/calendar");
		}
	       
	        
	     ModelAndView mv = new ModelAndView("redirect:/calendar");
	      return mv;
	   }
	   
	
	  // 내 일기 페이지로 이동
	   @RequestMapping(value = "/myDiaryPage", method = RequestMethod.GET)
	   public ModelAndView diaryList(HttpServletRequest req) {
	      ModelAndView mv = new ModelAndView("myDiary/myDiaryPage");
	      HttpSession session = req.getSession();
	      String email = session.getAttribute("loginEmail").toString();
	      List<DiaryVo> diaryList = diaryService.getdiaryList(email);
	      System.out.println("dadasdasdass"+diaryList);
//	      List<FileInfoVo> fileList = diaryService.getFileList();
//	      String realPath = sc.getRealPath("/resources/upload");   // 실제 저장될 서버의 경로이지만   
//	      mv.addObject("root", realPath);                    view에서는 servlet-context.xml에 있는 정보를 가지고 셋팅한다.          
	      mv.addObject("diaryList", diaryList);
	      return mv;
	   }
	   
	  @ResponseBody
	   @RequestMapping(value = "/mydiary", method = RequestMethod.POST)
	   public ModelAndView mydiary(@RequestParam("id") int d_no) {
		   System.out.println(d_no);
	      // 게시글 조회
	      DiaryVo vo =  diaryService.selectById(d_no);
	     // List<FileInfoVo> files = diaryService.selectReplyByIdFiles(Integer.valueOf(d_no));
	      
	      
	      // 첨부파일 조회
	      List<FileInfoVo> files = diaryService.selectReplyByIdFiles(Integer.valueOf(d_no));
	      

	      // 선택된 게시글의 뎃글 목록
	      //List<CommentVo> replys = diaryService.selectComment(vo.getB_no());
	      
	      ModelAndView mv = new ModelAndView("mainPage/mydiary");
	      mv.addObject("DiaryVo", vo);
	      mv.addObject("update",true);
//	      mv.addObject("replys", replys);
	      mv.addObject("files", files);
	      return mv;
	   }
	   
	   @RequestMapping(value = "/myDiaryPage", method = RequestMethod.POST)
	   public ModelAndView myDiaryPage() {
	      
	      ModelAndView mv = new ModelAndView("myDiary/myDiaryPage");
	   
	      return mv;
	   }
	   

	   @GetMapping("/image")
	   public ResponseEntity<byte[]> getImage() throws IOException {
	       URL url = new URL("http://localhost:8080/img/89dcf77d-18f4-4dbc-98a3-1418f7ef673b.jpg");
	       URLConnection connection = url.openConnection();
	       connection.connect();
	       InputStream inputStream = connection.getInputStream();
	       byte[] bytes = inputStream.readAllBytes();
	       
	      return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(bytes);
	   }
	   
	   @RequestMapping(value = "/delete", method = RequestMethod.POST)
		public void deleteDiary(@RequestParam("id") int d_no ) {
		   System.out.println("321w31232132131");
		   diaryService.deleteById(d_no);
			System.out.println(d_no);
			
	}
	   
	   
	}
	
	

package com.diary.project.controller;

import java.lang.System.Logger;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.view.RedirectView;

import com.diary.project.service.UserService;
import com.diary.project.vo.UserVo;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class LoginController {

	private static final String String = null;
	@Autowired
	private UserService userService;

	
	//여기부터 다솜수정(0318)
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("login");
		HttpSession session = req.getSession();
		mv.addObject("isLogin", false);
		if (session != null && session.getAttribute("loginEmail") != null) {
			mv.addObject("isLogin", true);
	
		}
		
		
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginPost(UserVo vo, HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("login");
		HttpSession session = req.getSession();
		System.out.println("####### session = " + session);
		if (session != null && session.getAttribute("loginEmail")!= null) {
			session.invalidate();
		}else {
			UserVo resultVo = userService.getMemberByEmail(vo.getU_email());
			System.out.println("resultVo="+resultVo);
			if (resultVo != null && resultVo.getU_pw().equals(vo.getU_pw())) {
				session.setAttribute("loginEmail", resultVo.getU_email());
				vo.setU_email(session.getAttribute("loginEmail").toString());
				System.out.println("33333333333"+vo.getU_email());
				mv = new ModelAndView("redirect:/calendar");
				
			}
		}
		System.out.println(session.getAttribute("loginEmail"));
		return mv;
		
	
	}
	//여기까지 추가됨 다솜수정(0318)

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView("register");
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(UserVo vo) {
				
		userService.insert(vo);
		ModelAndView mv = new ModelAndView("redirect:/login");
		return mv;
	}

	@ResponseBody
	@RequestMapping(value = "/duplicateId")
	public JSONArray duplicateId(String data) {
		ObjectMapper mapper = new ObjectMapper();
		JSONArray result = new JSONArray();
		try {
			JSONArray jsonarray = mapper.readValue(data, JSONArray.class);
			HashMap ja = (HashMap) jsonarray.get(0);
			System.out.println("--------");
			System.out.println(data);
			System.out.println(ja.get(0));
			String email = (String) ja.get("id");

			// ���� ȣ���ؼ� ���̵�� ��� �˻�
			UserVo vo = userService.getMemberByEmail(email);
			System.out.println("ddddddd");
			System.out.println(vo);
			if (vo != null)
				result.add(true);
			else
				result.add(false);

		} catch (Exception e) {
			e.printStackTrace();
			result.add(false);
		}
		return result;
	}

	@RequestMapping(value = "/idCheck")
	@ResponseBody
	public int idCheck(@RequestParam("id") String id) {

		int cnt = userService.idCheck(id);
		return cnt;
	}
@RequestMapping(value = "/nickCheck")
@ResponseBody
	public int nickCheck(@RequestParam("id") String id) {

		int cnt = userService.nickCheck(id);
		return cnt;
	}	

// 다솜 수정 03.19
@RequestMapping(value = "/logout" ,method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest req, HttpServletResponse res) {
	System.out.println("111111");
	HttpSession session = req.getSession();
	   session.invalidate();

	   ModelAndView mv = new ModelAndView("redirect:/login");
	   res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
	   res.addHeader("Cache-Control", "post-check=0, pre-check=0"); 
	   res.setHeader("Pragma", "no-cache");
	    return mv;
	       
}
	
@RequestMapping(value = "/updatePw", method = RequestMethod.GET)
public ModelAndView updatePw() {
	ModelAndView mv = new ModelAndView("profile/pwchange");
	return mv;
}
@RequestMapping(value = "/updateProfile", method = RequestMethod.GET)
public ModelAndView updateProfile() {
	ModelAndView mv = new ModelAndView("profile/prfchange");
	return mv;
}

// 프로필 업로드 버튼
@RequestMapping(value = "/updateProfile", method = RequestMethod.POST)
public ModelAndView updateProfiles(Map<String, Object> map,HttpServletRequest req) {
	HttpSession session = req.getSession();
	System.out.println("dasdasdas"+req.getParameter("u_am"));
	map.put("u_am",req.getParameter("u_am")); // 자기소개
	map.put("u_name",req.getParameter("u_name")); // 닉네임
	map.put("u_email",session.getAttribute("loginEmail")); // 세션에서 가져오는 이메일
//	map.put("u_am",req.getParameter("u_am")); // 사진업로드
	
	userService.updateProfile(map);
	ModelAndView mv = new ModelAndView("redirect:/calendar");
	return mv;
}

@RequestMapping(value = "/updatePw", method = RequestMethod.POST)
public ModelAndView updatePwPost(Map<String, Object> map, HttpServletRequest req){
	HttpSession session = req.getSession();
	ModelAndView mv = new ModelAndView();
	
	 map.put("u_pw", req.getParameter("u_pw"));
	 map.put("u_email", session.getAttribute("loginEmail"));
	 
	 userService.updatePw(map);
	 System.out.println("map의 값은 : "+map);
	
	
	RedirectView redirectView = new RedirectView(); // redirect url 설정
	redirectView.setUrl("/login");
	redirectView.setExposeModelAttributes(false);
	mv.setView(redirectView);
	
	session.invalidate();
	
	return mv;
	
}


	

}

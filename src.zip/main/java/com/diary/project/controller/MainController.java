package com.diary.project.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.diary.project.dao.DiaryDao;
import com.diary.project.service.DiaryService;
import com.diary.project.vo.DateData;
import com.diary.project.vo.DiaryVo;
import com.diary.project.vo.UserVo;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MainController {

	    private final  DiaryService diaryService;
	 
	    @GetMapping("/calendar-admin")
	    @ResponseBody
	    public List<Map<String, Object>> monthPlan() {
	  
	        List<DiaryVo> listAll = diaryService.findAll();
	        JSONObject jsonObj = new JSONObject();
	        JSONArray jsonArr = new JSONArray();
	 
	        HashMap<String, Object> hash = new HashMap<>();
	 
	        for (int i = 0; i < listAll.size(); i++) {
	            
	            hash.put("start", listAll.get(i).getD_today());
	                  
	            hash.put("title", listAll.get(i).getD_title());
                
                switch (listAll.get(i).getD_category()) {
             case "happy":
                 hash.put("backgroundColor","#FDF4E2" );
                 hash.put("borderColor", "#FDF4E2");
                 hash.put("textColor","#FF9F2D"); 
               
                break;
             case "sad":
                 hash.put("backgroundColor","#E2EAFD" );
                 hash.put("borderColor", "#E2EAFD");
                 hash.put("textColor","#1A53D0"); 
                
                break;
             case "angry":
                 hash.put("backgroundColor","#FDE4E2" );
                 hash.put("borderColor", "#FDE4E2");
                 hash.put("textColor","#D0301A");
             
                break;
             case "love":
                 hash.put("backgroundColor","#FCE2FD" );
                 hash.put("borderColor", "#FCE2FD");
                 hash.put("textColor","#EB4289");
            
                break;
             case "tired":
                 hash.put("backgroundColor","#E9FDE2" );
                 hash.put("borderColor", "#E9FDE2");
                 hash.put("textColor","#29D01A");
               
                break;
				default:
					break;
				}
	        	
	            jsonObj = new JSONObject(hash);
	            jsonArr.add(jsonObj);
	        }
	        
	       
	        return jsonArr;
	    }
	    
	    @RequestMapping(value = "/calendar", method = RequestMethod.GET)
		public ModelAndView calendar(UserVo vo,HttpServletRequest req) {
	    	 HttpSession session = req.getSession();
	    	 
		    vo.setU_email(session.getAttribute("loginEmail").toString());
		    List<UserVo> diaryinfo = diaryService.getdiaryListDiary(vo);
			ModelAndView mv = new ModelAndView("mainPage/calendar");
			mv.addObject("diaryList", diaryinfo);
			System.out.println(mv);
			System.out.println("dasdasdsaassa");
			return mv;
		}
	}
